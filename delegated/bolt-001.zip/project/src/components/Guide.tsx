import { useState } from 'react';
import { Building2, Landmark, MessageCircle, Info, ArrowLeft } from 'lucide-react';
import { businessAreas, type BusinessArea } from '@/data/businessAreas';

const areaIcons: Record<string, typeof Building2> = {
  'business-credit': Building2,
  'treasury-management': Landmark,
};

function AreaCard({
  area,
  isSelected,
  onSelect,
}: {
  area: BusinessArea;
  isSelected: boolean;
  onSelect: () => void;
}) {
  const Icon = areaIcons[area.id] ?? Building2;
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-pressed={isSelected}
      className={`w-full text-left rounded-token border transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 ${
        isSelected
          ? 'border-primary bg-primary text-paper shadow-md'
          : 'border-primary-200 bg-paper text-ink hover:border-primary-400 hover:shadow-sm'
      }`}
    >
      <div className="flex items-start gap-3 p-4">
        <div
          className={`flex-shrink-0 mt-0.5 transition-colors duration-200 ${
            isSelected ? 'text-accent' : 'text-primary-400'
          }`}
        >
          <Icon size={24} strokeWidth={1.5} />
        </div>
        <div className="min-w-0">
          <h3 className="font-heading text-lg font-bold leading-snug">
            {area.name}
          </h3>
          <p
            className={`text-sm leading-relaxed mt-0.5 ${
              isSelected ? 'text-primary-100' : 'text-primary-500'
            }`}
          >
            {area.tagline}
          </p>
        </div>
      </div>
    </button>
  );
}

function AreaDetail({ area, onBack }: { area: BusinessArea; onBack: () => void }) {
  return (
    <div
      role="region"
      aria-label={`${area.name} guide`}
      className="animate-[fadeIn_200ms_ease-out]"
    >
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-sm font-medium text-primary-500 hover:text-primary transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 rounded-token px-1 py-0.5"
      >
        <ArrowLeft size={16} strokeWidth={2} />
        All areas
      </button>

      <div className="mt-4">
        <h2 className="font-heading text-2xl font-bold text-primary">
          {area.name}
        </h2>
        <p className="text-primary-500 text-sm mt-1">{area.tagline}</p>
      </div>

      <div className="mt-5 flex items-start gap-2 rounded-token bg-warning-light border border-warning/30 p-3">
        <Info
          size={18}
          className="flex-shrink-0 text-warning mt-0.5"
          strokeWidth={1.5}
        />
        <p className="text-sm text-ink leading-relaxed">
          This summary is illustrative, not an official role description or
          transfer recommendation. It is a starting point for deciding what to
          ask an opted-in employee.
        </p>
      </div>

      <div className="mt-6">
        <h3 className="font-heading text-base font-bold text-primary">
          Typical work
        </h3>
        <ul className="mt-3 space-y-2.5">
          {area.typicalWork.map((item, index) => (
            <li
              key={index}
              className="flex items-start gap-2.5 text-sm text-ink leading-relaxed"
            >
              <span
                className="flex-shrink-0 mt-1.5 h-1.5 w-1.5 rounded-full bg-accent"
                aria-hidden="true"
              />
              {item}
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-6">
        <h3 className="font-heading text-base font-bold text-primary">
          Summary
        </h3>
        <p className="mt-2 text-sm text-ink leading-relaxed">{area.summary}</p>
      </div>

      <div className="mt-6 rounded-token border border-primary-100 bg-primary-50/50 p-4">
        <div className="flex items-center gap-2">
          <MessageCircle
            size={18}
            className="text-accent"
            strokeWidth={1.5}
          />
          <h3 className="font-heading text-base font-bold text-primary">
            Conversation starters
          </h3>
        </div>
        <p className="text-xs text-primary-500 mt-1 mb-3">
          Use these to open a low-pressure chat with someone who opted in.
        </p>
        <ul className="space-y-2">
          {area.conversationStarters.map((starter, index) => (
            <li
              key={index}
              className="text-sm text-ink leading-relaxed pl-4 border-l-2 border-accent/40"
            >
              {starter.prompt}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default function Guide() {
  const [selectedAreaId, setSelectedAreaId] = useState<string | null>(null);

  const selectedArea = businessAreas.find((a) => a.id === selectedAreaId) ?? null;

  return (
    <div className="min-h-screen bg-paper">
      <header className="border-b border-primary-100 bg-primary">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
          <p className="text-accent text-sm font-medium tracking-wide uppercase">
            Exploring Teams
          </p>
          <h1 className="font-heading text-2xl sm:text-3xl font-bold text-paper mt-1">
            Line-of-Business Guide
          </h1>
          <p className="text-primary-100 text-sm mt-2 max-w-xl leading-relaxed">
            A starting point for interns curious about another team. Browse
            example areas, read a short summary of typical work, and find
            conversation starters to bring to an opted-in employee.
          </p>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        {selectedArea ? (
          <AreaDetail
            area={selectedArea}
            onBack={() => setSelectedAreaId(null)}
          />
        ) : (
          <div>
            <h2 className="font-heading text-lg font-bold text-primary">
              Available example areas
            </h2>
            <p className="text-sm text-primary-500 mt-1 mb-4">
              Select an area to see its summary and conversation starters.
            </p>
            <div className="grid gap-3 sm:grid-cols-2">
              {businessAreas.map((area) => (
                <AreaCard
                  key={area.id}
                  area={area}
                  isSelected={false}
                  onSelect={() => setSelectedAreaId(area.id)}
                />
              ))}
            </div>
          </div>
        )}
      </main>

      <footer className="border-t border-primary-100 mt-8">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-5">
          <p className="text-xs text-primary-400 leading-relaxed">
            Summaries are illustrative and based on interview research, not
            official role descriptions. This guide does not create a transfer
            request or carry any standing impact.
          </p>
        </div>
      </footer>
    </div>
  );
}
