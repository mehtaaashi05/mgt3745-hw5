export interface ConversationStarter {
  prompt: string;
}

export interface BusinessArea {
  id: string;
  name: string;
  tagline: string;
  summary: string;
  typicalWork: string[];
  conversationStarters: ConversationStarter[];
}

export const businessAreas: BusinessArea[] = [
  {
    id: 'business-credit',
    name: 'Business Credit',
    tagline: 'Evaluating lending risk for companies',
    summary:
      'Business Credit analysts assess the financial health of companies seeking loans or credit facilities. They review financial statements, industry trends, and repayment capacity to recommend credit decisions. The role blends quantitative analysis with judgment about business risk.',
    typicalWork: [
      'Spreading and analyzing financial statements to assess borrower health',
      'Researching industry trends and competitive positioning',
      'Writing credit memos that recommend approval, decline, or modified terms',
      'Monitoring existing borrowers for changes in risk profile',
      'Collaborating with relationship managers on loan structuring',
    ],
    conversationStarters: [
      { prompt: 'What does a typical day look like when you are evaluating a new borrower?' },
      { prompt: 'How much of the work is independent analysis versus collaborative decision-making?' },
      { prompt: 'What surprised you about the role that you did not expect from the outside?' },
    ],
  },
  {
    id: 'treasury-management',
    name: 'Treasury Management',
    tagline: 'Managing liquidity and payments for corporate clients',
    summary:
      'Treasury Management teams help corporate clients optimize cash flow, manage working capital, and execute payments. They work with products like wire transfers, ACH, lockbox, and fraud prevention tools. The role sits between operations and client advisory, solving practical cash-management problems.',
    typicalWork: [
      'Advising clients on cash-flow optimization and payment routing',
      'Configuring treasury products such as ACH, wires, and sweep accounts',
      'Resolving payment exceptions and fraud alerts',
      'Onboarding new corporate clients to treasury platforms',
      'Coordinating with operations and technology teams on product issues',
    ],
    conversationStarters: [
      { prompt: 'How do you explain treasury products to a client who is new to them?' },
      { prompt: 'What is the balance between operational problem-solving and longer-term advisory work?' },
      { prompt: 'What skills from this role transfer well to other areas of the bank?' },
    ],
  },
];
