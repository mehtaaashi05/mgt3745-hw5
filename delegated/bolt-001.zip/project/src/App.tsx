import Guide from '@/components/Guide';

function App() {
  return <Guide />;
}

export default App;
