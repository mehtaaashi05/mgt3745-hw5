/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#051E39',
          50: '#E8EDF3',
          100: '#D1DCE7',
          200: '#A3B8CF',
          300: '#7593B7',
          400: '#476E9F',
          500: '#2A4A7A',
          600: '#1A3A5E',
          700: '#102A47',
          800: '#0A1E35',
          900: '#051E39',
        },
        accent: {
          DEFAULT: '#B39051',
          50: '#F8F1E3',
          100: '#F0E0C0',
          200: '#E0C996',
          300: '#D0B574',
          400: '#C0A062',
          500: '#B39051',
          600: '#967843',
          700: '#7A6035',
          800: '#5E4828',
          900: '#42301B',
        },
        success: {
          DEFAULT: '#2D6A4F',
          light: '#D8F3DC',
        },
        warning: {
          DEFAULT: '#B47A2A',
          light: '#FDF0D5',
        },
        error: {
          DEFAULT: '#A6232A',
          light: '#FBE3E4',
        },
        ink: '#1A1A1A',
        paper: '#FFFFFF',
      },
      fontFamily: {
        body: ['Roboto', 'system-ui', 'sans-serif'],
        heading: ['"Roboto Slab"', 'Georgia', 'serif'],
      },
      fontSize: {
        'min': ['14px', '1.5'],
      },
      spacing: {
        'unit': '8px',
      },
      borderRadius: {
        'token': '4px',
      },
    },
  },
  plugins: [],
};
